#include <stdio.h>
#include <stdlib.h>

int main() {
    FILE *inputFile = fopen("input.txt", "r");
    FILE *outputFile = fopen("output.txt", "w");
    char ch;
    int state = 0;

    if (inputFile == NULL || outputFile == NULL) {
        printf("Error opening file.\n");
        return 1;
    }

    while ((ch = fgetc(inputFile)) != EOF) {
        if (ch == ' ' || ch == '\t') {
            if (state == 0) {
                fputc(' ', outputFile);
                state = 1;
            }
        } else {
            fputc(ch, outputFile);
            state = 0;
        }
    }

    fclose(inputFile);
    fclose(outputFile);

    return 0;
}