#include <stdio.h>
#include <string.h>
#include <ctype.h> 

int isPalindrome(char *str) {
    char *left = str; 
    char *right = str + strlen(str) - 1; 

    while (left < right) { 
        if (tolower(*left) != tolower(*right)) { // 
            return 0; 
        }
        left++; 
        right--; 
    }
    return 1; 
}

int main() {
    char str[256];
    printf("Enter a string: ");
    scanf("%255s", str); 

    if (isPalindrome(str)) {
        printf("Palindrome\n");
    } else {
        printf("Not Palindrome\n");
    }

    return 0;
}