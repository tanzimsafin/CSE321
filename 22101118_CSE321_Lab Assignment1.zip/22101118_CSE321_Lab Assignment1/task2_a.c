#include <stdio.h>
int add(int a, int b) {
    return a + b;
}

int subtract(int a, int b) {
    return a - b;
}


int multiply(int a, int b) {
    return a * b;
}

int main() {
    int num1, num2;
    char operator;

    printf("Enter first number: ");
    scanf("%d", &num1);
    printf("Enter second number: ");
    scanf("%d", &num2);
    printf("Enter a operator: ");
    scanf(" %c", &operator); 
    if (operator == '+') {
        if (num1 > num2) {
            printf("Result: %d\n", subtract(num1, num2));
        } else if (num1 < num2) {
            printf("Result: %d\n", add(num1, num2));
        } else {
            printf("Result: %d\n", multiply(num1, num2));
        }
    } else if (operator == '-') {
        if (num1 > num2) {
            printf("Result: %d\n", subtract(num1, num2));
        } else if (num1 < num2) {
            printf("Result: %d\n", add(num1, num2));
        } else {
            printf("Result: %d\n", multiply(num1, num2));
        }
    } else if (operator == '*') {
        if (num1 > num2) {
            printf("Result: %d\n", subtract(num1, num2));
        } else if (num1 < num2) {
            printf("Result: %d\n", add(num1, num2));
        } else {
            printf("Result: %d\n", multiply(num1, num2));
        }
    } else {
        printf("Invalid operator.\n");
    }

    return 0;
}

