 #include <stdio.h>
#include <ctype.h> // For character checking functions

int main() {
    char password[256];
    printf("Enter your password: ");
    scanf("%255s", password);

    int hasLower = 0, hasUpper = 0, hasDigit = 0, hasSpecial = 0;

    // Iterate through each character of the password
    for (int i = 0; password[i] != '\0'; i++) {
        if (islower(password[i])) hasLower = 1; 
        else if (isupper(password[i])) hasUpper = 1; 
        else if (isdigit(password[i])) hasDigit = 1;
        else if (password[i] == '_' || password[i] == '$' || password[i] == '#' || password[i] == '@') hasSpecial = 1; 
    }

   
    if (!hasLower) printf("Lowercase character missing");
    if (!hasUpper) printf("Uppercase character missing");
    if (!hasDigit) printf("Digit missing");
    if (!hasSpecial) printf("Special character missing\n");

    if (hasLower && hasUpper && hasDigit && hasSpecial) printf("OK\n");

    return 0;
}