#include <stdio.h>
#include <string.h>


void checkEmailDomain(const char* email) {
    // Check if the email ends with "@sheba.xyz"
    if (strstr(email, "@sheba.xyz") != NULL) {
        printf("Email address is okay\n");
    } else {
        printf("Email address is outdated\n");
    }
}

int main() {
    char email[256]; 

    printf("Enter email address: ");
    scanf("%255s", email); 


    checkEmailDomain(email);

    return 0;
}